#include <Arduino.h>
#include "filter.h"


/**
 * @brief Default constructor for the Filter class.
 * 
 * Initializes the filter parameters to 0.0.
 */
Filter::Filter() {
    p1 = 0.0;
    p2 = 0.0;
    p3 = 0.0;
    p4 = 0.0;
}

/**
 * @brief Constructs a Filter object with the given parameters.
 *
 * @param p1 The value of parameter p1.
 * @param p2 The value of parameter p2.
 * @param p3 The value of parameter p3.
 * @param p4 The value of parameter p4.
 */
Filter::Filter(float p1, float p2, float p3, float p4) {
    this->p1 = p1;
    this->p2 = p2;
    this->p3 = p3;
    this->p4 = p4;
}

/**
 * @brief Applies a filter to the input value.
 *
 * This function applies a filter to the input value using a buffer and filter coefficients.
 * The buffer stores the previous input values, and the filter coefficients determine the weights
 * applied to each value in the buffer.
 *
 * @param input The input value to be filtered.
 * @return The filtered output value.
 */
float Filter::update(float input) {
    // Shift buffer
    buffer[3] = buffer[2];
    buffer[2] = buffer[1];
    buffer[1] = buffer[0];
    buffer[0] = input;

    // Perform filtering
    return p1 * buffer[0] + p2 * buffer[1] + p3 * buffer[2] + p4 * buffer[3];
}
