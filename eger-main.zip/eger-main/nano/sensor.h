#include <Arduino.h>
#include "filter.h"
/**
 * @file sensor.h
 * @brief Contains the declaration of the Sensor class.
 */

#ifndef SENSOR_H
#define SENSOR_H

/**
 * @class Sensor
 * @brief Represents a sensor for measuring distance using an IR sensor.
 * 
 * The Sensor class provides functionality to measure distance using an IR sensor. It includes methods to check if the distance is too close or too far, as well as a filter to smooth the distance values. The class also includes constants for the minimum and maximum distances considered too close and too far, respectively.
 */
class Sensor {
private:
    const float tooCloseDistance = 10.0; /**< The minimum distance considered too close, in mm. */
    const float tooFarDistance = 250.0; /**< The maximum distance considered too far, in mm. */

    bool tooClose; /**< Flag indicating if the distance is too close. */
    bool tooFar; /**< Flag indicating if the distance is too far. */
    float distance_mm; /**< The measured distance in mm. */
    const uint8_t* lut; /**< Lookup table for converting raw IR sensor readings to distance values. */
    byte LED_pin; /**< The pin number for the LED. */
    byte IR_pin; /**< The pin number for the IR sensor. */
    Filter filter; /**< The filter used to smooth the distance values. */

public:  
    /**
     * @brief Default constructor.
     * Initializes the sensor with default values.
     */
    Sensor();

    /**
     * @brief Constructor.
     * Initializes the sensor with the provided lookup table and pin numbers.
     * @param lut The lookup table for converting raw IR sensor readings to distance values.
     * @param LED_pin The pin number for the LED.
     * @param IR_pin The pin number for the IR sensor.
     */
    Sensor(uint8_t* lut, byte LED_pin, byte IR_pin);

    /**
     * @brief Updates the sensor readings.
     * Turns on the LED, reads the IR sensor, converts the analog value to distance,
     * filters the distance value, and checks if the distance is too close or too far.
     */
    void update();

    /**
     * @brief Gets the measured distance.
     * @return The measured distance in mm.
     */
    float getDistance();

    /**
     * @brief Checks if the distance is too close.
     * @return True if the distance is too close, false otherwise.
     */
    bool isTooClose();

    /**
     * @brief Checks if the distance is too far.
     * @return True if the distance is too far, false otherwise.
     */
    bool isTooFar();       
};

#endif // SENSOR_H