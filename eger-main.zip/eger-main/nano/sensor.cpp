#include <Arduino.h>
#include "sensor.h"

/**
 * @brief Default constructor.
 * Initializes the sensor with default values.
 */
Sensor::Sensor(){
    this->lut = nullptr;
    this->filter = Filter();
}

/**
 * @brief Constructor.
 * Initializes the sensor with the provided lookup table and pin numbers.
 * @param lut The lookup table for converting raw IR sensor readings to distance values.
 * @param LED_pin The pin number for the LED.
 * @param IR_pin The pin number for the IR sensor.
 */
Sensor::Sensor(uint8_t* lut, byte LED_pin, byte IR_pin){
    this->lut = lut;
    pinMode(LED_pin, OUTPUT);
    pinMode(IR_pin, INPUT);
    this->filter = Filter(0.25, 0.25, 0.25, 0.25);
}

/**
 * @brief Updates the sensor readings.
 * Turns on the LED, reads the IR sensor, converts the analog value to distance,
 * filters the distance value, and checks if the distance is too close or too far.
 */
void Sensor::update() {
    digitalWrite(LED_pin, HIGH);
    delay(1);
    uint16_t raw = analogRead(IR_pin);
    digitalWrite(LED_pin, LOW);
    distance_mm = lut[raw];
    float filtered_distance = filter.update(distance_mm);
    tooClose = filtered_distance < tooCloseDistance;
    tooFar = filtered_distance > tooFarDistance;
}

/**
 * @brief Gets the measured distance.
 * @return The measured distance in mm.
 */
float Sensor::getDistance() {
    return distance_mm;
}

/**
 * @brief Checks if the distance is too close.
 * @return True if the distance is too close, false otherwise.
 */
bool Sensor::isTooClose() {
    return tooClose;
}

/**
 * @brief Checks if the distance is too far.
 * @return True if the distance is too far, false otherwise.
 */
bool Sensor::isTooFar() {
    return tooFar;
}