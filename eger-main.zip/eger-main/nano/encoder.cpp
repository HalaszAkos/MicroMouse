/**
 * @file encoder.cpp
 * @brief Implementation file for the Encoder class.
 */

#include <Arduino.h>
#include "encoder.h"

/**
 * @brief Constructor for the Encoder class.
 * @param cycleTime The time interval between updates in milliseconds.
 * @param Ch1_pin The pin number for channel 1 of the encoder.
 * @param Ch2_pin The pin number for channel 2 of the encoder.
 */
Encoder::Encoder(uint8_t Ch1_pin, uint8_t Ch2_pin, Direction direction)
{
    if(direction == FORWARD)
        this->direction = 1;
    else
        this->direction = -1;

    pulse = 0;
    this->Ch1_pin = Ch1_pin;
    this->Ch2_pin = Ch2_pin;
    pinMode(Ch1_pin, INPUT);
    pinMode(Ch2_pin, INPUT);
}

/**
 * @brief Constructor for the Encoder class with additional parameters.
 * @param cycleTime The time interval between updates in milliseconds.
 * @param Ch1_pin The pin number for channel 1 of the encoder.
 * @param Ch2_pin The pin number for channel 2 of the encoder.
 * @param pulsePerRevolution The number of pulses per revolution of the encoder.
 * @param gearRatio The gear ratio of the system.
 * @param wheelPerimeter The perimeter of the wheel in millimeters.
 */
Encoder::Encoder(uint8_t Ch1_pin, uint8_t Ch2_pin, uint8_t pulsePerRevolution, Direction direction, uint8_t gearRatio, uint8_t wheelPerimeter)
{
    if(direction == FORWARD)
        this->direction = 1;
    else
        this->direction = -1;

    pulse = 0;
    this->Ch1_pin = Ch1_pin;
    this->Ch2_pin = Ch2_pin;
    this->pulsePerRevolution = pulsePerRevolution;
    this->gearRatio = gearRatio;
    this->wheelPerimeter = wheelPerimeter;  
    pinMode(Ch1_pin, INPUT);
    pinMode(Ch2_pin, INPUT);
}

/**
 * @brief Increment the pulse count.
 */
void Encoder::increment(){
    pulse++;
}

/**
 * @brief Decrement the pulse count.
 */
void Encoder::decrement(){
    pulse--;
}

/**
 * @brief Reset the pulse count to zero.
 */
void Encoder::resetPosition(){
    pulse = 0;
}

/**
 * @brief Get the position in millimeters.
 * @return The position in millimeters.
 */
int16_t Encoder::getPosition_mm(){
    float position = (float)pulse/pulsePerRevolution/gearRatio*wheelPerimeter; 
    return (int16_t)position * direction;
}

/**
 * @brief Get the speed in millimeters per second.
 * @return The speed in millimeters per second.
 */
int16_t Encoder::getSpeed(){    
    return (int16_t)speed * direction;
}

/**
 * @brief Get the current pulse count.
 * @return The current pulse count.
 */
int16_t Encoder::getPulse(){
    return pulse;
}

/**
 * @brief Update the speed values based on the time elapsed since the last update.
 */
void Encoder::updateValues()
{
    uint64_t currentTime = millis();
    uint64_t delayTime = currentTime - lastTime;
    
    float currentPosition = (float)pulse/pulsePerRevolution/gearRatio * wheelPerimeter;
    speed = (currentPosition - lastPosition) / (float)delayTime * 1000;
    lastTime = currentTime;
    lastPosition = currentPosition;
    
}

/**
 * @brief Update the pulse count based on the state of channel 2 of the encoder.
 */
void Encoder::pulseCount(){
    if(digitalRead(Ch2_pin) == HIGH){
        pulse++;
    }else{
        pulse--;
    }
}


