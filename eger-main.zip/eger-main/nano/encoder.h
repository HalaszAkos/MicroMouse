#ifndef ENCODER_H
#define ENCODER_H

#include <Arduino.h>

class Encoder
{
  private:
    float pulsePerRevolution = 7;
    float gearRatio = 19.0/2.0;     
    float wheelPerimeter = 140.0; //mm    
    uint64_t lastTime = 0;

    //float currentPosition = 0;
    float lastPosition = 0;
    

    uint8_t Ch1_pin;
    uint8_t Ch2_pin;
    uint64_t cycleTime = 0;

    int32_t pulse = 0;

    int8_t direction = 1;

  public: 
    float speed = 0;

    enum Direction {
      FORWARD = 1,
      REVERSE = -1
    };    
    Encoder(uint8_t Ch1_pin, uint8_t Ch2_pin, Direction direction ); // Constructor (user defined values for pulsePerRevolution, gearRatio, wheelPerimeter)
    Encoder(uint8_t Ch1_pin, uint8_t Ch2_pin, uint8_t pulsePerRevolution, Direction direction, uint8_t gearRatio, uint8_t wheelPerimeter); // Constructor (user defined values for pulsePerRevolution, gearRatio, wheelPerimeter)

    void pulseCount();
    void increment();
    void decrement();
    void resetPosition();
    int16_t getPosition_mm();
    int16_t getPulse();
    int16_t getSpeed();

    void updateValues();

};

#endif