#include <Arduino.h>
#include <QuickPID.h>
#include <TimerEvent.h>
#include <Wire.h>

#include "sensor.h"
#include "encoder.h"

// pin definitions
#define I2C_SDA 18  //a4  
#define I2C_SCL 19 //a5
int IRSensorL1 = A0;  // Analog input
int IRSensorL2 = A1;  // Analog input
int IRSensorR1 = A2;  // Analog input
int IRSensorR2 = A3;  // Analog input
 
int IRSensorL1_EN = 9;  // Digital input
int IRSensorL2_EN = 8;  // Digital input
int IRSensorR1_EN = 7;  // Digital input
int IRSensorR2_EN = 6;  // Digital input
 
uint16_t SensorL1value = 0;
uint16_t SensorL2value = 0;
uint16_t SensorR1value = 0;
uint16_t SensorR2value = 0;


byte i2c_rcv;               // data received from I2C bus

// Encoder pins deffinitions
// Motor1: Left
uint8_t L_Enc_ChA_pin = 3;
uint8_t L_Enc_ChB_pin = 5;
// Motor2: Right
uint8_t R_Enc_ChA_pin = 2;
uint8_t R_Enc_ChB_pin = 4;

Encoder L_Encoder = Encoder(L_Enc_ChA_pin, L_Enc_ChB_pin, Encoder::FORWARD);
Encoder R_Encoder = Encoder(R_Enc_ChA_pin, R_Enc_ChB_pin, Encoder::REVERSE);

// cycle time declarations
TimerEvent Timer_10ms;
TimerEvent Timer_40ms;
TimerEvent Timer_100ms;




//uint64_t lastTime = 0;


//Filter SpeedFilter = Filter(0.25, 0.25, 0.25, 0.25);

//uint16_t lastPosition = 0;

//float speed = 600;



// PID
//const uint32_t sampleTimeUs = 100000; // 100ms
//volatile bool computeNow = false;

//Define Variables we'll be connecting to
//float Setpoint, Input, Output;

// Üresen ezzel a beállítással 600mm/s ra stabil volt a rendszer
// float Kp = 0.1, Ki = 0.7, Kd = 0.025;

//float Kp = 0.45, Ki = 0.7, Kd = 0.3;

//specify the links
//QuickPID myPID(&Input, &Output, &Setpoint);


// Functions declarations
void i2cReceiveCallback(int aCount);
void i2cTelegramSend();




// void runPid(){
//   Input = SpeedFilter.update(L_Encoder.speed);
//   myPID.Compute();
//   analogWrite(MotorPWM, Output);
//   Serial.print(L_Encoder.speed);
//   Serial.print(", ");
//   Serial.println(Output);
// }


void L_Enc_PulseISR()
{
  L_Encoder.pulseCount();
}

void R_Enc_PulseISR()
{
  R_Encoder.pulseCount();
}

void Cycle_10ms()
{
  // Update the encoder speed values
  L_Encoder.updateValues();
  R_Encoder.updateValues();

  // Read the IR sensors
  SensorL1value = analogRead(IRSensorL1);
  SensorL2value = analogRead(IRSensorL2);
  SensorR1value = analogRead(IRSensorR1);
  SensorR2value = analogRead(IRSensorR2);
}

void Cycle_40ms()
{
  
}


void Cycle_100ms()
{
  Serial.print(L_Encoder.getPosition_mm());
  Serial.print(", ");
  Serial.println(R_Encoder.getPosition_mm());    
}


void setup() {

  Wire.begin(0x08);
  Wire.onReceive(i2cReceiveCallback);
  Wire.onRequest(i2cTelegramSend);

  Serial.begin(115200);  

  pinMode(IRSensorL1_EN, OUTPUT);
  pinMode(IRSensorL2_EN, OUTPUT);
  pinMode(IRSensorR1_EN, OUTPUT);
  pinMode(IRSensorR2_EN, OUTPUT);
 
  digitalWrite(IRSensorL1_EN, HIGH);
  digitalWrite(IRSensorL2_EN, HIGH);
  digitalWrite(IRSensorR1_EN, HIGH);
  digitalWrite(IRSensorR2_EN, HIGH);

  // pinMode(MotorIN1, OUTPUT);
  // pinMode(MotorIN2, OUTPUT);
  // pinMode(MotorPWM, OUTPUT);
  // digitalWrite(MotorIN1, HIGH);
  // digitalWrite(MotorIN2, LOW);
  
  // Set up timed event to call mySensor.update() every 100 milliseconds  
  attachInterrupt(digitalPinToInterrupt(L_Enc_ChA_pin), L_Enc_PulseISR, RISING);
  attachInterrupt(digitalPinToInterrupt(R_Enc_ChA_pin), R_Enc_PulseISR, RISING);


  //apply PID gains
  //myPID.SetTunings(Kp, Ki, Kd);

  //turn the PID on
  //myPID.SetMode(QuickPID::Control::automatic);
  

  Timer_10ms.set(10, Cycle_10ms);
  Timer_40ms.set(40, Cycle_40ms);
  Timer_100ms.set(100, Cycle_100ms);

}

void loop() {
  Timer_10ms.update();
  Timer_40ms.update();
  Timer_100ms.update();
}

void i2cReceiveCallback(int aCount)
{
  if(aCount == 2)
  {
    //Serial.println("I2C Receive");
    int receivedValue  = Wire.read() << 8; 
    receivedValue |= Wire.read();
    //Serial.println(receivedValue);


   // int receivedValue2  = Wire.read() << 8; 
    //receivedValue2 |= Wire.read();
   // Serial.println(receivedValue2);
  }
  else
  {
    Serial.print("Unexpected number of bytes received: ");
    Serial.println(aCount);
  }
}

void i2cTelegramSend(){
  // Send sensor values
  Wire.write(SensorL1value >> 8);
  Wire.write(SensorL1value & 255);

  Wire.write(SensorL2value >> 8);
  Wire.write(SensorL2value & 255);

  Wire.write(SensorR1value >> 8);
  Wire.write(SensorR1value & 255);

  Wire.write(SensorR2value >> 8);
  Wire.write(SensorR2value & 255);

  // Collect position and speed datas
  int16_t L_Position = L_Encoder.getPosition_mm();
  int16_t R_Position = R_Encoder.getPosition_mm();
  int16_t L_Speed = L_Encoder.getSpeed();
  int16_t R_Speed = R_Encoder.getSpeed();

  // Serial.print(L_Position);
  // Serial.print(", ");
  // Serial.print(R_Position);
  // Serial.print(", ");
  // Serial.print(L_Speed);
  // Serial.print(", ");
  // Serial.println(R_Speed);

  // Send position values
  Wire.write(L_Position >> 8);
  Wire.write(L_Position & 255);
  Wire.write(R_Position >> 8);
  Wire.write(R_Position & 255);

  // Send speed values
  Wire.write(L_Speed >> 8);
  Wire.write(L_Speed & 255);
  Wire.write(R_Speed >> 8);
  Wire.write(R_Speed & 255);
}

