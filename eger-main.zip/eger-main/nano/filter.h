
#include <Arduino.h>

#ifndef FILTER_H
#define FILTER_H

/**
 * @file filter.h
 * @brief Contains the declaration of the Filter class.
 */

/**
 * @class Filter
 * @brief Represents a filter that applies a weighted average to a series of input values.
 */
class Filter {
private:
    float p1; /**< The value of parameter p1. */
    float p2; /**< The value of parameter p2. */
    float p3; /**< The value of parameter p3. */
    float p4; /**< The value of parameter p4. */
    float buffer[4] = {0.0, 0.0, 0.0, 0.0}; /**< The buffer to store previous input values. */

public:
    /**
     * @brief Default constructor for the Filter class.
     * 
     * Initializes the filter parameters to 0.0.
     */
    Filter();

    /**
     * @brief Constructs a Filter object with the given parameters.
     *
     * @param p1 The value of parameter p1.
     * @param p2 The value of parameter p2.
     * @param p3 The value of parameter p3.
     * @param p4 The value of parameter p4.
     */
    Filter(float p1, float p2, float p3, float p4);

    /**
     * @brief Applies a filter to the input value.
     * 
     * This function applies a filter to the input value using a buffer and filter coefficients.
     * The buffer stores the previous input values, and the filter coefficients determine the weights
     * applied to each value in the buffer.
     * 
     * @param input The input value to be filtered.
     * @return The filtered output value.
     */
    float update(float input);
};

#endif // FILTER_H